import static org.junit.Assert.*;

import javax.swing.JButton;

import org.junit.Before;
import org.junit.Test;

public class TestClient {
	Game client;
	
    @Before
    public void setUp() {
        client = new Game("59001");
    }
    
	@Test
	public void testClickLetter() {
		JButton letter = new JButton();
		letter.setText("H");
		client.checkLetter(letter);
		assertFalse(letter.isEnabled());	
	}
	
	@Test
	public void testDoubleClick() {
		JButton letter = new JButton();
		letter.setText("H");
		client.checkLetter(letter);
		client.checkLetter(letter);
		assertFalse(letter.isEnabled());
			
	}
	
	@Test
	public void testSpaces() {
		String word = "word";
		assertTrue(client.stuffSpaces(word).equals("w o r d"));	
	}
	
	@Test
	public void testUpdatedString() {
		String word = "____";
		client.setInput("word");
		assertTrue(client.getUpdatedString(word, 'd').equals("___d"));	
	}
	
	@Test
	public void testUpdatedStringAlreadyDone() {
		String word = "___d";
		client.setInput("word");
		assertTrue(client.getUpdatedString(word, 'd').equals("___d"));	
	}
	
	@Test
	public void testUpdatedStringNotEmpty() {
		String word = "w__d";
		client.setInput("word");
		assertTrue(client.getUpdatedString(word, 'o').equals("wo_d"));	
	}
	
	

}
