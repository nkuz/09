import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A server for a hangman game with single and multiplayer modes. I created a plain text-protocol with
 * the following messages:
 *
 * Client -> Server
 * NEWWORD
 * REPLAY
 * UPDATETOSERVER
 * MESSAGE
 * 
 * Server -> Client
 * SUBMITNAME
 * NAMEACCEPTED
 * COMPUTERMODE
 * TWOPLAYERMODE
 * GAMESTART
 * UPDATETOPLAYER
 * GETPARTNER
 * MESSAGE
**/

public class HangmanServer {
    
	/** 
	* All client names and print writers to check for duplicates upon registration 
	* and easily lookup client's partners.
	*/
    private static Map<String, PrintWriter> users = new HashMap<String, PrintWriter>();

    // Reference to user waiting to be matched to another player
    private static PrintWriter availableWriter = null;
    private static String availableUser = null;

    // Sets up multithreading and opens a server socket. 
    public static void main(String[] args) throws Exception {
        System.out.println("Running the Hangman server!");
        ExecutorService pool = Executors.newFixedThreadPool(500);
        try (ServerSocket listener = new ServerSocket(59001)) {
            while (true) {
                pool.execute(new Handler(listener.accept()));
            }
        }
    }

	private static class Handler implements Runnable {
	    private String name;
	    private String mode;
	    private Socket socket;
	    private Scanner in;
	    private PrintWriter out;
	
	
	    /**
	     * Constructs a handler thread, squirreling away the socket. All other
	     * work is done in the run method. 
	     */
	    public Handler(Socket socket) {
	        this.socket = socket;
	    }
	
	    /**
	     * Services this thread's client by:
	     * - repeatedly requesting a screen name until a unique one has been submitted
	     * - acknowledges the name and registers the output stream for the client in a global set
	     * - receiving and processing game type (single vs. multiplayer) 
	     *   by immediately beginning single player games and matching available users with 
	     *   opponents for multi-player ones
	     * - repeatedly receiving, processing, and broadcasting in-game inputs between
	     *   just the two partners in each concurrent multiplayer game.
	     */
	    public void run() {
	        try {
	            in = new Scanner(socket.getInputStream());
	            out = new PrintWriter(socket.getOutputStream(), true);
	
	            // Keep requesting a name until we get a unique one.
	            while (true) {
	                out.println("SUBMITNAME");
	                name = in.nextLine();
	                if (name == null) {
	                    return;
	                }
	                synchronized (users) {
	                    if (!name.equals("") && !users.containsKey(name)) {
	                        users.put(name, out);
	                        break;
	                    }
	                }
	            }
	           out.println("NAMEACCEPTED " + name);   
	           
	           // Set the correct game mode for this user, with 0 being single-player
	           // and 1 being multi-player
		        mode = in.nextLine();

	            if (mode.equals("0")) {
	            	out.println("COMPUTERMODE");
	            }
	            else if (mode.equals("1")) { 
		            // If there are no users waiting to be matched, this user is placed in the
	            	// waiting spot
	            	if (availableWriter == null) {
	            		availableWriter = out;
	            		availableUser = new String(name);
	            		out.println("MESSAGE " + "Waiting for a new user to connect to the server!");
	            	}
		            // Inform both users of their partners and begin the game with the one on
	            	// the waitlist playing first, and the new player choosing first
	            	else {
	            		availableWriter.println("MESSAGE " + name + " will be playing hangman with you today!");
	            		out.println("MESSAGE " + availableUser + " will be playing hangman with you today!");
	            		
		            	out.println("TWOPLAYERMODE" + "2" + availableUser);
		            	availableWriter.println("TWOPLAYERMODE" + "1" + name);
		            	
		            	availableWriter = null;
		            	availableUser = null;
	            	}
	            }
	                  
	            // Endlessly accept, process, and broadcast inputs to the client and their partner.
	            while (true) {
	            	String input = in.nextLine();
	                if (input.toLowerCase().startsWith("/quit")) {
	                    return;
	                }
	            	if (mode.equals("1")) {
	            		out.println("GETPARTNER");
		                String partner = in.nextLine();
		                // if player 2 chooses a word, begin the game
		                if (input.startsWith("NEWWORD")) {
		                	String word = input.substring(7);
		                	System.out.println(word);
		                	users.get(partner).println("GAMESTART" + word);
		                }
		                // when player 1 makes move, update player 2's GUI
		                else if (input.startsWith("UPDATETOSERVER")) {
		                	String update = input.substring(14);
		                	users.get(partner).println("UPDATETOPLAYER" + update);
		                }
		                // when a game completes, switch player 1 and 2's roles
		                // from chooser to player and reset the GUI
		                else if (input.startsWith("REPLAY")) {
		                	out.println("TWOPLAYERMODE" + "2" + partner);
		                	users.get(partner).println("TWOPLAYERMODE" + "1" + name);
		                }
		                // update the chat by relaying and messages between the two partners
		                else {
			                out.println("MESSAGE " + name + ": " + input);
			                users.get(partner).println("MESSAGE " + name + ": " + input);
		                }
		                
	            	}
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        } finally {
	        	// close the thread if the client leaves and remove them from all game states
	            if (name != null) {
	                System.out.println(name + " is leaving");
	                // if the client occupied the wait slot, clear the slot
	                if (name.contentEquals(availableUser)) {
	                	availableUser = null;
	                	availableWriter = null;
	                }
	                users.remove(name);
	                // tell the partner in a multi-player game if the client leaves
	                if (mode.equals("1")) {
	                    out.println("GETPARTNER");
		                String partner = in.nextLine();
		                users.get(partner).println("MESSAGE " + name + " has left the game :(");
	                }
	            }
	            try { socket.close(); } catch (IOException e) {}
	        }
	    }
		
	}
}

