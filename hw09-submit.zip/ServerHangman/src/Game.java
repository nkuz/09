import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Game {
    private String serverAddress;
    private Scanner in;
    private PrintWriter out;
    private JFrame frame;
    private JTextField textField;;
    private JTextArea messageArea;
    private JPanel left, right, letterArea, guessingArea, bottomRight, chatArea, controlArea, scoreArea;
    private JButton generator;
    private JTextArea lines, lettersGuessed, notification, score1, score2;
    private JLabel labelTopLeft;
    private ImageIcon image, noose; 
    private String inputString = null;
    private String unrevealedText, username;
    private String partner = null;
    private int wrongGuess, letterCount, mode, player, yourScore, partnerScore;
    private String guesses = "          Wrong Guesses: \n          ";
    private List<String> words; 

    //Constructs and updates the client's GUI depending on game mode as well as client, partner, and server input
    public Game(String serverAddress) {
        this.serverAddress = serverAddress;
        words = readDictionary();
        makeFrame();

        // Send on enter then clear to prepare for next message
        textField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                out.println(textField.getText());
                textField.setText("");
            }
        });
    }
   
    // Basic frame setup
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Pass the server IP as the sole command line argument");
            return;
        }
        Game client = new Game(args[0]);
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.frame.setVisible(true);
        client.run();
    }
    
    /**
     * Handles all input from the client and determines appropriate field and GUI changes
     * @throws IOException if the socket cannot be connected to
     */
    @SuppressWarnings("resource")
	private void run() throws IOException {
    	try {
            Socket socket = new Socket(serverAddress, 59001);
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);

            while (in.hasNextLine()) {
                String line = in.nextLine();
                // Calls dialogue box with name request
                if (line.startsWith("SUBMITNAME")) {
                    out.println(getName());
                } 
                // Changes client state to request username approval and
                // calls dialogue box with game mode requests
                else if (line.startsWith("NAMEACCEPTED")) {
                    this.frame.setTitle("Hangman - " + line.substring(13));
                    username = line.substring(13);
                    out.println(getMode());
                } 
                /* If a message is sent with a null player field, this is a message from the server
                 * informing both users about their future match
                 * Otherwise, this is an update to the chat between two already matched players
                 */
                else if (line.startsWith("MESSAGE")) {
                	if (partner == null) {
                		setTwoPlayerMode();
                	}
                    messageArea.append(line.substring(8) + "\n");
                }
                // Update GUI to reflect single-player mode
                else if (line.startsWith("COMPUTERMODE")) {
                    setComputerMode();
                }
                // Assign player roles and call to update GUI to reflect multi-player mode
                else if (line.startsWith("TWOPLAYERMODE")) {
                   textField.setEditable(true); 
                   partner = line.substring(14);
                   beginTwoPlayer(Integer.parseInt(line.substring(13,14)));
                }
                // relay partner name to server
                else if (line.startsWith("GETPARTNER")) {
                	out.println(partner);
                }
                // Set up GUI when the other player has chosen a word for the client to guess
                else if (line.startsWith("GAMESTART")) {
                	inputString = new String(line.substring(9).toUpperCase());
                	System.out.println(inputString);
                	player = 1;
                	setUp();
                }
                // Update GUI every time the other player has chosen a letter
                else if (line.startsWith("UPDATETOPLAYER")) {
                	String letter = line.substring(14);
                	 for (Component c : letterArea.getComponents()) {      
     	             	if (c instanceof JButton && ((JButton)c).getText().equals(letter)) {
     	             		checkLetter(((JButton)c));
     	                 }  
     	             }
                }
            }
        }
    	finally {
            frame.setVisible(false);
            frame.dispose();
        }
    }
    
    /**
     * The following three methods are dialog boxes to determine 
     * username, game mode, and the word to be guessed (if in multiplayer)
     * All three relay this infomation back to the server.
     * 
     */
    private String getName() {
        return JOptionPane.showInputDialog(
            frame,
            "Choose a screen name:",
            "Screen name selection",
            JOptionPane.PLAIN_MESSAGE
        );
    }
    
    private int getMode() {
    	Object[] options = {
                "No, I'd like to play a computer",
                "Yes, match me up with a random user on this server!"};
    	return JOptionPane.showOptionDialog(frame,
    			"Would you like play against a live user? ",
    					"Mode Selection",
    					JOptionPane.YES_NO_CANCEL_OPTION,
    					JOptionPane.QUESTION_MESSAGE,
						null,
						options,
						options[0]);
    }
    
    private void getWord() {
    	
        String input = JOptionPane.showInputDialog(
            frame,
            "Type the word you'd like your partner to guess below!",
            "Word Selection",
            JOptionPane.PLAIN_MESSAGE
        );
        while (!words.contains(input)) {
    		input = JOptionPane.showInputDialog(
    	            frame,
    	            "Please enter a valid word in the English language.",
    	            "Word Selection",
    	            JOptionPane.PLAIN_MESSAGE
    	            );
    	}
        
        inputString = new String(input).toUpperCase();
        generator.setEnabled(false);
        player = 2;
        setUp();
    	out.println("NEWWORD" + inputString);
    }

    /**
     * Create the dictionary of valid words for both the computer & the choosing user to pick from
     * @return each word in the text file as an entry in a list
     */
    protected List<String> readDictionary() {
        String word;
        List<String> w = new ArrayList<String>();

        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("words.txt"));

            while ((word = bufferedReader.readLine()) != null) {
                w.add(word);
            }

            bufferedReader.close();
        } catch (IOException e) {
            System.out.println(e.getMessage()); //prints IO exception is file is not found
        }

        return w;
    }
    
    // Employ JAVA SWING to setup the elements in common for both play modes
    public void makeFrame() {
        frame = new JFrame("Hangman");
        left = new JPanel();
        right = new JPanel();
        letterArea = new JPanel();
        guessingArea = new JPanel();
        bottomRight = new JPanel();
        chatArea = new JPanel();
        controlArea = new JPanel();
        scoreArea = new JPanel();
        
        
        letterArea.setLayout(new GridLayout(5,6));
        
        labelTopLeft = new JLabel();
        image = new ImageIcon("images/first.png");
        labelTopLeft.setIcon(image);
        left.add(labelTopLeft);
        
        textField = new JTextField(30);
        messageArea = new JTextArea(16, 30);
        lines = new JTextArea();  
        lines.setFont(new Font("Serif", Font.BOLD, 22));
        lettersGuessed = new JTextArea();
        lettersGuessed.setFont(new Font("Serif", Font.BOLD, 22));
        
        score1 = new JTextArea();
        score1.setFont(new Font("Serif", Font.BOLD, 18));
        score2 = new JTextArea();
        score2.setFont(new Font("Serif", Font.BOLD, 18));

        
        frame.setLayout(new GridLayout(1,2));
        frame.add(left);
        frame.add(right);
        
        right.setLayout(new GridLayout(3,1));
        right.add(letterArea);
        right.add(guessingArea);
        right.add(bottomRight);
        
        lines.setEditable(false);
        lettersGuessed.setEditable(false);
        guessingArea.setLayout(new GridLayout(1,2));
        guessingArea.add(lines);
        guessingArea.add(lettersGuessed);
        
        makeAlphabet();
        
        frame.pack();
        frame.setSize(1500,920);     
    }
    
    // Create the buttons to select from
    private void makeAlphabet() {
        for (char currentLetter = 'A'; currentLetter <= 'Z';currentLetter++) {
            JButton button = new JButton((new Character(currentLetter)).toString());
            letterArea.add(button);
        }   
    }
    
    // Set up broad GUI component of single player mode
    private void setComputerMode() {
        mode = 1;
        player = 1;
    	bottomRight.setLayout(new GridLayout(1,1));

    	generator = new JButton(" GENERATE RANDOM WORD");
        generator.setFont(new Font("Serif", Font.BOLD, 22));
        generator.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { setUp(); }
        });

        bottomRight.add(generator);
        
        frame.pack();
        frame.setSize(1500,920);
        frame.setVisible(true);
    }
    
    //set up broad GUI component of multi player mode, divides screen into chat and game status area
    private void setTwoPlayerMode() {
    	mode = 2;
    	bottomRight.setLayout(new GridLayout(1,2));
        bottomRight.add(chatArea);
        bottomRight.add(controlArea);

        textField.setEditable(false);
        messageArea.setEditable(false);
        
        chatArea.add(new JScrollPane(messageArea), BorderLayout.CENTER);
        chatArea.add(textField, BorderLayout.SOUTH);
        
        frame.pack();
        frame.setSize(1500,920);
        frame.setVisible(true);
    }
    
    // set up fields and action listeners for both modes
    private void setUp() {
        noose = new ImageIcon("images/noose1.png");
        labelTopLeft.setIcon(noose);
        letterCount = 0;
        guesses = "          Wrong Guesses: \n          ";
        lettersGuessed.setText(guesses);
        wrongGuess = 1;
        for (Component c : letterArea.getComponents()) {      
        	if (c instanceof JButton) {
        	   if (player == 1) {
        		   ((JButton)c).setEnabled(true);
        		   if (((JButton)c).getActionListeners().length == 0) {
	        		   ((JButton)c).addActionListener(new ActionListener() {
	                       public void actionPerformed(ActionEvent e) { checkLetter((JButton)c); }
	                   });
        		   }
        		   if (mode == 2) {
        	         notification.setText(                    "Guess away :)");
        		   }
        	   }
        	   else {
        		   ((JButton)c).setEnabled(false);
        	   }
            }  
        }
        newWord();
    }
    
    // Update GUI to reflect that a partner has been found and the game will begin
    private void beginTwoPlayer(int plyr) {
        controlArea.removeAll();
    	controlArea.setLayout(new GridLayout(2,1));
    	scoreArea.setLayout(new GridLayout(1,2));

    	if (plyr == 2) {
	        generator = new JButton("Start new game");
	        generator.setFont(new Font("Serif", Font.BOLD, 20));
	        generator.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) { getWord();}
	         });
	        controlArea.add(generator);
        }
        else {
        	notification = new JTextArea();
        	notification.setText("\n \n      A word will appear above once your partner selects one!");
        	controlArea.add(notification);
        }
    	
    	score1.setText(username + "'s score is: \n" + yourScore);
    	score2.setText(partner + "'s score is: \n" + partnerScore);
    	scoreArea.add(score1);
    	scoreArea.add(score2);
    	controlArea.add(scoreArea);
    	
        frame.pack();
        frame.setSize(1500,920);
        frame.setVisible(true);
    }
    
 
    // Update GUI every time a key is pressed to reflect correctness of choice
    public void checkLetter(JButton letter) {
   	 	letter.setEnabled(false);
    	if (mode == 2 && player == 1) {
    		out.println("UPDATETOSERVER" + letter.getText());
    	 }
        if ((inputString.indexOf(letter.getText()) == -1) && (inputString.indexOf(letter.getText().toLowerCase()) == -1)) {    
        	 addAnswer(letter);
             labelTopLeft.setIcon(new ImageIcon("images/noose" + (new Integer(wrongGuess+1)).toString() + ".png"));
             wrongGuess++;
             if (player == 1) {
         		yourScore--;
         	 }
         	 if (player == 2) {
         		partnerScore--;
         	 }
             if (wrongGuess == 11)
             {
            	 if (player == 1 && mode == 2) {
            		 resetGame();
            	 }
            	 else {
            		 lines.setText(stuffSpaces(inputString));
            	 }
                 wrongGuess--;
             }
         }
         else {
             updateDashes(letter);
         }
         
     }
    
     // Formats incorrect guesses in GUI
     private void addAnswer(JButton letter) {
         guesses += letter.getText() + " ";
         letterCount++;
         if (letterCount >= 3)
         {
             guesses += "\n          ";
             letterCount = 0;
         }
         
         lettersGuessed.setText(guesses);
     }
     
     /**
      *  Generates a brand new word from the list if applicable and updates GUI with 
      *  dashed letters in the beginning of every game
      */
     private void newWord() {
         if (mode == 1) {
	    	 int randomNum = (int)(Math.random() * words.size()); 
	         inputString = words.get(randomNum).toUpperCase();
         }
         
         unrevealedText = new String(new char[inputString.length()]).replace("\0", "_");
         lines.setText(stuffSpaces(unrevealedText));
     }
     
     // Updates unrevealed text, user score, and checks for winner after each guess
     private void updateDashes(JButton letter) {
         unrevealedText = getUpdatedString(unrevealedText,letter.getText().charAt(0));

         if (stuffSpaces(unrevealedText).equals(stuffSpaces(inputString.toUpperCase()))) {
             if (player == 1) {
            	 unrevealedText += "\n You Won!";
             }
             else {
            	 unrevealedText += "\n Your partner won...";
             }
             if (mode == 2 && player == 1) {
	             resetGame();
             }
         }
         if (mode == 2) {
	         lines.setText(stuffSpaces(unrevealedText));
	         score1.setText(username + "'s score is: \n" + yourScore);
	     	 score2.setText(partner + "'s score is: \n" + partnerScore);
         }
     }
     
     // Informs server to switch player roles
     private void resetGame() {
	     for (Component c : letterArea.getComponents()) {      
	      	if (c instanceof JButton) {
	      		((JButton)c).setEnabled(false); 
	          }  
	      }
	      lines.setText(stuffSpaces(unrevealedText));
	      out.println("REPLAY");
     }
     
     // Formats unrevealed text
     public String stuffSpaces(String input)
     {
         StringBuilder result = new StringBuilder("\n ");
         for (int i=0; i<input.length(); i++) {
             result.append(input.charAt(i));
             result.append(" ");
         }
         return result.toString();
     }
     
     // Creates a new dashed string after each guess
     String getUpdatedString(String dashed, char letter)
     {
         StringBuilder result = new StringBuilder(dashed);
         for (int i = 0; i < dashed.length(); i++) {
             if (inputString.charAt(i)==letter) {
            	 if (player == 1) {
            		yourScore++;
            	 }
            	 if (player == 2) {
            		partnerScore++;
            	 }
                 result.setCharAt(i,letter);
             }
         }
         return result.toString();
     }
     
     public void setInput(String i) {
    	inputString = i;
     }
    
}