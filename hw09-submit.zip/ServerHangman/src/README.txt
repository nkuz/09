There are just two public and self-explanatory files in the game - HangmanClient and HangmanServer. 
Inside HangmanServer, the Handler class services each thread that connects to the server.
The way I run my program is by launching the server and individual clients from separate .bat files 
in my explorer window.

My game is implemented through communication with a main server through a text-based protocol I created,
which enables clients to choose between single and multi-player modes of hangman.

The first concept I used was Collections. I used a HashMap to store all clients in the server and an ArrayList
to store all of the words in my dictionary.

The second concept I used was File I/O to verify that the initial input is made up of valid words.
I use a large text file with about 10,000 words in the English language and the initial input is parsed into words 
with a buffered reader and cross-referenced with this text file to make sure all of the words are valid.

The third concept I used was Testing, and I tested the client so that the graphics and point values are correctly updated, 
that no button can be pressed twice, and that the GUI is correctly updated during the guessing process.

The fourth concept I used was Network I/O to relay messages about scores, moves, and initial word choice across the server
to the other player. This was by far the most difficult concept to implement!